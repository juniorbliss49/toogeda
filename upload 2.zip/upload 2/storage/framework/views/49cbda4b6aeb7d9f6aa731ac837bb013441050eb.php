<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <h1>Create a post!</h1>
            <p class="lead">Remember you must have a valid license plate number.</p>
        </div>
    </div>
    <div class="container section">
        <div class="row">
            <div class="col-md-8">
                <?php if(! empty(Auth::user()->license_num)): ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <form action="/post" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group<?php echo e(($errors->has('name'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__name">Name</label>
                        <input type="text" class="form-control" id="form__name" name="name" value="<?php echo e(old('name')); ?>" required maxlength="255">
                        <?php if($errors->has('name')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('description'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__description">Description</label>
                        <textarea class="form-control" id="form__description" name="description" rows="3" required><?php echo e(old('description')); ?></textarea>
                        <?php if($errors->has('description')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('description')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('num_riders'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__num_riders">Number of Riders</label>
                        <input type="number" class="form-control" id="form__num_riders" name="num_riders" value="<?php echo e(old('num_riders')); ?>" required min="0">
                        <?php if($errors->has('num_riders')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('num_riders')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('departure_pcode'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__departure_pcode">Source City</label>
                        <input type="text" class="form-control" id="form__departure_pcode" name="departure_pcode" value="<?php echo e(old('departure_pcode')); ?>" required maxlength="7" pattern="[A-z]\d[A-z]\s?\d[A-z]\d$">
                        <small class="form-control-feedback">
                            eg. Waec bus stop, Yaba
                        </small>
                        <?php if($errors->has('departure_pcode')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('departure_pcode')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('destination_pcode'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__destination_pcode">Destination city</label>
                        <input type="text" class="form-control" id="form__destination_pcode" name="destination_pcode" value="<?php echo e(old('destination_pcode')); ?>" required maxlength="7" pattern="^[A-z]\d[A-z]\s?\d[A-z]\d$">
                        <small class="form-control-feedback">
                            Eko hotel round about, yaba
                        </small>
                        <?php if($errors->has('destination_pcode')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('destination_pcode')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <legend>Trip Type</legend>
                        <label class="form-check-inline">
                            <input class="form-check-input" type="radio" name="type" value="1" <?php echo e((old('type') == 1 || old('type') == null)? 'checked' : ''); ?>> Local Trip
                        </label>
                        <label class="form-check-inline">
                            <input class="form-check-input" type="radio" name="type" value="0" <?php echo e((old('type') == 0 && old('one_time') != null)? 'checked' : ''); ?>> Long Distance Trip
                        </label>
                    </div>
                    <div class="form-group">
                        <legend>One Time or Frequent</legend>
                        <label class="form-check-inline">
                            <input class="form-check-input" type="radio" name="one_time" value="1" <?php echo e((old('one_time') == 1 || old('one_time') == null)? 'checked' : ''); ?>> One Time
                        </label>
                        <label class="form-check-inline">
                            <input class="form-check-input" type="radio" name="one_time" value="0" <?php echo e((old('one_time') == 0 && old('one_time') != null)? 'checked' : ''); ?>> Frequent
                        </label>
                    </div>
                    <div class="form-group onet-wrap<?php echo e(($errors->has('departure_date'))? ' has-danger' : ''); ?><?php echo e((old('one_time') == 1 || old('one_time') == null)? ' active' : ''); ?>">
                        <label class="form-control-label" for="form__departure_date">Departure Date</label>
                        <input type="date" class="form-control form-reset" id="form__departure_date" name="departure_date" value="<?php echo e(old('departure_date')); ?>" min="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>">
                        <?php if($errors->has('departure_date')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('departure_date')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="type-wrap<?php echo e((old('type') == 1 || old('type') == null)? ' active' : ''); ?>">
                        <div class="freq-wrap<?php echo e((old('one_time') == 0 && old('one_time') != null)? ' active' : ''); ?>">
                            <div class="form-group">
                                <legend>Frequency</legend>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_sun" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_sun" value="1" <?php echo e(old('every_sun')? 'checked': ''); ?>> Sunday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_mon" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_mon" value="1" <?php echo e(old('every_mon')? 'checked': ''); ?>> Monday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_tues" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_tues" value="1" <?php echo e(old('every_tues')? 'checked': ''); ?>> Tuesday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_wed" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_wed" value="1" <?php echo e(old('every_wed')? 'checked': ''); ?>> Wednesday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_thur" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_thur" value="1" <?php echo e(old('every_thur')? 'checked': ''); ?>> Thursday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_fri" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_fri" value="1" <?php echo e(old('every_fri')? 'checked': ''); ?>> Friday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_sat" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_sat" value="1" <?php echo e(old('every_sat')? 'checked': ''); ?>> Saturday
                                </label>
                            </div>
                        </div>
                        <div class="form-group<?php echo e(($errors->has('time'))? ' has-danger' : ''); ?>">
                            <label for="form__time">Departure Time</label>
                            <input type="time" class="form-control form-reset" id="form__time" name="time" value="<?php echo e(old('time')); ?>">
                            <?php if($errors->has('time')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('time')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="type-wrap<?php echo e((old('type') == 0)? ' active' : ''); ?>">
                        <div class="freq-wrap<?php echo e((old('one_time') == 0)? ' active' : ''); ?>">
                            <div class="form-group">
                                <label for="">Frequency</label>
                                <select class="form-control" name="frequency">
                                    <option value="0" <?php echo e((old('frequency') == 0)? 'selected' : ''); ?>>Every Sunday</option>
                                    <option value="1" <?php echo e((old('frequency') == 1)? 'selected' : ''); ?>>Every Monday</option>
                                    <option value="2" <?php echo e((old('frequency') == 2)? 'selected' : ''); ?>>Every Tuesday</option>
                                    <option value="3" <?php echo e((old('frequency') == 3)? 'selected' : ''); ?>>Every Wednesday</option>
                                    <option value="4" <?php echo e((old('frequency') == 4)? 'selected' : ''); ?>>Every Thursday</option>
                                    <option value="5" <?php echo e((old('frequency') == 5)? 'selected' : ''); ?>>Every Friday</option>
                                    <option value="6" <?php echo e((old('frequency') == 6)? 'selected' : ''); ?>>Every Saturday</option>
                                    <option value="7" <?php echo e((old('frequency') == 7)? 'selected' : ''); ?>>Twice-Monthly</option>
                                    <option value="8" <?php echo e((old('frequency') == 8)? 'selected' : ''); ?>>Monthly</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary">Create Post!</button>
                </form>
                <?php else: ?>
                    <h3>Sorry!</h3>
                    <p class="lead">You must add a license plate number to your account before creating a post!</p>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <h3>Need Help?</h3>
                <p>Verification is done physically at our office at number Eko Hotel, VI, Lagos. Please come with your car and its particulars.</p>
            </div>
        </div>
    </div>

    <script>
        $(function(){
            var $type_selection = $('input[name="type"]');
            var $freq_selection = $('input[name="one_time"]');
            var $type_wrap = $('.type-wrap');
            var $freq_wrap = $('.freq-wrap');
            var $onet_wrap = $('.onet-wrap');
            var inputs = $('.form-reset');

            $type_selection.change(function(){
                var val = $(this).val();
                $('.type-wrap.active').removeClass('active');
                $type_wrap.eq(++val % 2).addClass('active');
                inputs.val('');
            });
            $freq_selection.change(function(){
                var val = $(this).val();
                if(val == 1){
                    $freq_wrap.removeClass('active');
                    $onet_wrap.addClass('active');
                } else {
                    $freq_wrap.addClass('active');
                    $onet_wrap.removeClass('active');
                }
                inputs.val('');
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>