<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <h1 class="display-4">
                Compose a message to someone.
            </h1>
            <p class="lead">Getting in touch!</p>
        </div>
    </div>
    <div class="container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/mail">Mail Inbox</a></li>
            <li class="breadcrumb-item"><a href="/mail/sent">Mail Sent</a></li>
            <li class="breadcrumb-item active">Compose Message</li>
        </ol>
        <div class="row">
            <div class="col-sm-6">
                <form action="/mail" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="">Recipient</label>
                        <select name="recipient_id" class="form-control" required>
                            <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php if($user->id == Auth::user()->id): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                <option value="<?php echo e($user->id); ?>" <?php if($recipient != null && $user->id == $recipient->id): ?> selected <?php endif; ?>>
                                    <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="form__body">Your Message</label>
                        <textarea class="form-control" id="form__body" rows="5" name="body" placeholder="Drop a message..." minlength="1"></textarea>
                    </div>
                    <button class="btn btn-primary" type="submit">Send!</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>