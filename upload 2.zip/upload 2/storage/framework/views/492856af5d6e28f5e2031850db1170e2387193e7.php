<?php $__env->startSection('content'); ?>
    <div class="container section">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <img class="card-img-top img-fluid" src="<?php echo e($user->avatarUrl(340)); ?>" alt="">
                    <div class="card-block">
                        <h4 class="card-title text-xs-center"><?php echo e($user->first_name . ' ' . $user->last_name); ?></h4>
                        <div class="row flex-items-xs-between text-xs-center">
                            <div class="col-xs">
                                <div><?php echo e($user->getRating()); ?></div>
                                <div>rating</div>
                            </div>
                            <div class="col-xs">
                                <div><?php echo e($user->posts()->count()); ?></div>
                                <div>posts</div>
                            </div>
                            <div class="col-xs">
                                <div><?php echo e($user->rides()->count() + $user->hosts()->count()); ?></div>
                                <div>trips</div>
                            </div>
                        </div>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item text-muted">
                            <?php if($user->updated_at->diffInMonths(\Carbon\Carbon::now()) < 3): ?>
                                <small>Active, had activity <?php echo e($user->updated_at->diffForHumans()); ?>.</small>
                            <?php else: ?>
                                <small>Inactive more than 3 months.</small>
                            <?php endif; ?>
                        </li>
                        <?php if($user->external_email && $user->is_visible_external_email): ?>
                            <li class="list-group-item">
                                <?php echo e($user->external_email); ?>

                            </li>
                        <?php endif; ?>
                        <?php if($user->address && $user->is_visible_address): ?>
                            <li class="list-group-item" data-toggle="tooltip" data-placement="bottom" title="Address">
                                <?php echo e($user->address); ?>

                            </li>
                        <?php endif; ?>
                        <?php if($user->license_num && $user->is_visible_license_num): ?>
                            <li class="list-group-item" data-toggle="tooltip" data-placement="bottom" title="License">
                                <?php echo e($user->license_num); ?>

                            </li>
                        <?php endif; ?>
                        <?php if($user->birth_date && $user->is_visible_birth_date): ?>
                            <li class="list-group-item" data-toggle="tooltip" data-placement="bottom" title="Birthday">
                                <?php echo e($user->birth_date->toFormattedDateString()); ?>

                            </li>
                        <?php endif; ?>
                        <?php if($user->policies && $user->is_visible_policies): ?>
                            <li class="list-group-item" data-toggle="tooltip" data-placement="bottom" title="Policies">
                                <?php $__currentLoopData = $user->policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <span class="tag tag-default"><?php echo e($policy); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <div class="card-block">
                        <a href="<?php echo e(url('mail/compose?recipient_id=' . $user->id)); ?>" class="card-link">Send Message</a>
                        <?php if(Auth::user()->id == $user->id || Auth::user()->hasRole('admin')): ?>
                            <a href="<?php echo e(route('user.edit', ['user' => $user->id])); ?>" class="card-link">Edit Profile</a>
                        <?php endif; ?>
                    </div>
                    <?php if(Auth::user()->id == $user->id): ?>
                        <div class="card-footer">
                            <label for="">Your referral id.</label>
                            <input type="text" class="form-control disabled" value="<?php echo e($user->referral_id); ?>">
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(Auth::user()->id == $user->id || Auth::user()->hasRole('admin')): ?>
                    <ul class="list-group">
                        <?php if(count($old_posts) > 0): ?>
                            <li class="list-group-item">
                                <h5 class="font-weight-light">Old Posts</h5>
                                <?php $__currentLoopData = $old_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $old_post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="sidebar-item">
                                        <a class="d-block" href="/post/<?php echo e($old_post->id); ?>"><?php echo e($old_post->name); ?></a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </li>
                        <?php endif; ?>
                        <?php if(count($old_trips) > 0): ?>
                            <li class="list-group-item">
                                <h5 class="font-weight-light">Old Trips</h5>
                                <?php $__currentLoopData = $old_trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $old_trip): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="sidebar-item">
                                        <small class="text-muted"><?php echo e($old_trip->status()); ?></small>
                                        <a class="d-block" href="/trip/<?php echo e($old_trip->id); ?>"><?php echo e($old_trip->name); ?></a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </li>
                        <?php endif; ?>
                        <?php if(count($old_hosts) > 0): ?>
                            <li class="list-group-item">
                                <h5 class="font-weight-light">Old Hosted Trips</h5>
                                <?php $__currentLoopData = $old_hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $old_host): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="sidebar-item">
                                        <small class="text-muted"><?php echo e($old_host->status()); ?></small>
                                        <a class="d-block" href="/trip/<?php echo e($old_host->id); ?>"><?php echo e($old_host->name); ?></a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </li>
                        <?php endif; ?>
                        <?php if(count($old_hosts) == 0 && count($old_trips) == 0 && count($old_posts) == 0): ?>
                            <li class="list-group-item">
                                <h5 class="font-weight-light text-xs-center mb-0">No Archive <i class="fa fa-archive"></i></h5>
                            </li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="col-md-9">
                <?php if(count($user->posts) == 0): ?>
                    <table class="h-100 w-100">
                        <tbody>
                            <tr>
                                <td class="align-middle text-xs-center">
                                    <h3>This user has no posts. <i class="fa fa-frown-o"></i></h3>
                                    <p class="text-muted">Maybe one day.</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif; ?>
                <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="card mb-1">
                        <div class="card-block">
                            <div><small>Posted <?php echo e($post->created_at->diffForHumans()); ?></small></div>
                            <h4 class="card-title"><a href="/post/<?php echo e($post->id); ?>"><?php echo e($post->name); ?></a>
                            </h4>
                            <p class="card-text"><?php echo e(substr($post->description, 0, 260) . ((strlen($post->description) > 160)? '...' : '')); ?></p>
                            <div>
                                S: <?php echo e($post->departure_pcode); ?> | E: <?php echo e($post->destination_pcode); ?> |
                                <?php echo e($post->cost()); ?> | <i class="fa fa-comments-o"></i> <?php echo e(count($post->messages)); ?> |
                                Max riders: <?php echo e($post->num_riders); ?> |
                                <a href="#"><i  class="fa fa-map" data-toggle="modal" data-target="#post-modal-<?php echo e($loop->index); ?>"></i></a>
                                <div class="modal fade" id="post-modal-<?php echo e($loop->index); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <iframe class="w-100" height="360" src="https://www.google.com/maps/embed/v1/directions?origin=<?php echo e($post->departure_pcode); ?>&destination=<?php echo e($post->destination_pcode); ?>&key=AIzaSyCgfUnLm9_WaYa9hov9l8z4dhVdUuQ6nRg"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if($post->postable_type != \App\LocalTrip::class): ?>
                                <div>From: <?php echo e($post->postable->departure_city); ?>, <?php echo e($post->postable->departure_province); ?> | To: <?php echo e($post->postable->destination_city); ?>, <?php echo e($post->postable->destination_province); ?></div>
                            <?php endif; ?>
                            <div>
                                <?php if(! $post->one_time): ?>
                                    <?php if($post->postable_type == \App\LocalTrip::class): ?>
                                        <?php echo e($post->postable->displayFrequency()); ?>

                                    <?php else: ?>
                                        <?php echo e($post->postable->displayFrequency()); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="tag-container">
                                <div class="tag tag-default"><?php echo e(($post->postable_type == \App\LocalTrip::class)? 'Local' : 'Long Distance'); ?></div>
                                <div class="tag tag-info"><?php echo e(($post->one_time)? 'One Time' : 'Frequent'); ?></div>
                            </div>
                        </div>
                        <?php if(canEdit($user->id)): ?>
                            <div class="card-footer">
                                <a href="/post/<?php echo e($post->id); ?>/edit" class="btn btn-outline-info">Update</a>
                                <a href="#" class="delete btn btn-outline-danger"><i class="fa fa-trash"></i> Delete</a>
                                <form action="/post/<?php echo e($post->id); ?>/" method="post" style="display: none">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>