<?php $__env->startSection('content'); ?>
    <div class="container section">
        <h2 class="display-4 mb-2">
            Hello <?php echo e(Auth::user()->fullName()); ?>!
        </h2>
<!--
        <?php if($announcement->value): ?>
            <div class="card">
                <div class="card-header">
                    Public Announcement (<?php echo e($announcement->updated_at->diffForHumans()); ?>)
                </div>
                <div class="card-block">
                    <div class="card-text">
                        <?php echo e($announcement->value); ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>
      -->
        <div class="card mb-2">
            <div class="card-block p-1" style="background-color: #f3f3f3;">
                <form action="" class="form-inline">
                    <div class="form-group<?php echo e(($errors->has('postal_start')? ' has-danger' : '' )); ?>">
                        <input type="text" class="form-control" name="postal_start" placeholder="Source City" value="Victoria"  maxlength="30">
                        <?php if($errors->has('postal_start')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('postal_start')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('postal_end')? ' has-danger' : '' )); ?>">
                        <input type="text" class="form-control" name="postal_end" placeholder="Destination City"  maxlength="30">
                        <?php if($errors->has('postal_end')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('postal_end')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <select name="radius" id="" class="form-control" title="Radius" required>
                            <?php for($i = 5; $i <= 50; $i += 5): ?>
                                <option value="<?php echo e($i); ?>"<?php echo e(($search['radius'] == $i)? ' selected' : ''); ?>><?php echo e($i); ?> KM</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <label class="form-check-inline">
                        <input class="form-check-input" type="radio" name="type" value="0"<?php echo e((request()->type != 0)? '' : ' checked'); ?>> Recurring
                    </label>
                    <label class="form-check-inline">
                        <input class="form-check-input" type="radio" name="type" value="1"<?php echo e((request()->type != 1)? '' : ' checked'); ?>> One Way Trip
                    </label>
                    <label class="form-check-inline">
                        <input class="form-check-input" type="radio" name="type" value="2"<?php echo e((request()->type != 2)? '' : ' checked'); ?>> Round Trip
                    </label>
                    <button class="btn btn-primary float-xs-right" type="submit">Search</button>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
                <div class="card-deck">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="card card-post mb-1">
                            <div class="card-block">
                                <div><small>Posted <?php echo e($post->created_at->diffForHumans()); ?></small></div>
                                <h4 class="card-title"><a href="/post/<?php echo e($post->id); ?>"><?php echo e($post->name); ?></a>
                                </h4>
                                <p class="card-text"><?php echo e(substr($post->description, 0, 160) . ((strlen($post->description) > 160)? '...' : '')); ?></p>
                                <div>
                                <?php if($post->postable_type == \App\LocalTrip::class): ?>
                                    S: <?php echo e($post->departure_pcode); ?> | E: <?php echo e($post->destination_pcode); ?> |
                                <?php endif; ?>
                                    <?php echo e($post->cost()); ?> | <i class="fa fa-comments-o"></i> <?php echo e(count($post->messages)); ?> | <i class="fa fa-car" aria-hidden="true"></i>: <?php echo e($post->num_riders); ?> |
                                    <a href="#"><i  class="fa fa-map" data-toggle="modal" data-target="#post-modal-<?php echo e($loop->index); ?>"></i></a>
                                    <div class="modal fade" id="post-modal-<?php echo e($loop->index); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <iframe class="w-100" height="360" src="https://www.google.com/maps/embed/v1/directions?origin=<?php echo e($post->departure_pcode); ?>&destination=<?php echo e($post->destination_pcode); ?>&key=AIzaSyCgfUnLm9_WaYa9hov9l8z4dhVdUuQ6nRg"></iframe>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if($post->postable_type != \App\LocalTrip::class): ?>
                                    <div>
                                        S: <?php echo e($post->postable->departure_city); ?>, <?php echo e($post->postable->departure_province); ?> | E: <?php echo e($post->postable->destination_city); ?>, <?php echo e($post->postable->destination_province); ?>

                                    </div>
                                <?php endif; ?>
                                <!--<div class="tag-container">
                                    <div class="tag tag-default tag-trip"><?php echo e(($post->postable_type == \App\LocalTrip::class)? 'Local' : 'Long Distance'); ?></div>
                                    <div class="tag tag-info"><?php echo e(($post->one_time)? 'One Time' : 'Frequent'); ?></div>
                                </div> -->
                            </div>
                            <div class="card-footer">
                                <div class="media">
                                    <a class="media-left" href="/user/<?php echo e($post->poster->id); ?>">
                                        <img class="media-object rounded-circle" src="<?php echo e($post->poster->avatarUrl(45)); ?>" width="45">
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading" style="font-size: 14px">Posted By</h4>
                                        <?php echo e($post->poster->fullName()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
                <small class="text-muted">Found <?php echo e(count($posts)); ?> results.</small>
            </div>
            <div class="col-md-3">
                <ul class="list-group">
                    <?php if(count($current_trips) > 0): ?>
                        <li class="list-group-item">
                            <h5 class="font-weight-light">Current Trips</h5>
                            <?php $__currentLoopData = $current_trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current_trip): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="sidebar-item">
                                    <small class="text-muted"><?php echo e($current_trip->status()); ?></small>
                                    <a class="d-block" href="/trip/<?php echo e($current_trip->id); ?>"><?php echo e($current_trip->name); ?></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </li>
                    <?php endif; ?>
                    <?php if(count($posted_trips)> 0): ?>
                        <li class="list-group-item">
                            <h5 class="font-weight-light">Hosting Trips</h5>
                            <?php $__currentLoopData = $posted_trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posted_trip): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="sidebar-item">
                                    <small class="text-muted"><?php echo e($posted_trip->status()); ?></small>
                                    <a class="d-block" href="/trip/<?php echo e($posted_trip->id); ?>"><?php echo e($posted_trip->name); ?></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </li>
                    <?php endif; ?>
                    <li class="list-group-item">
                        <h5 class="font-weight-light">Notifications</h5>
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="sidebar-item notifications">
                                <a href="<?php echo e($notification->data['url']); ?>"><?php echo e($notification->data['message']); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php if(count($notifications) == 0): ?>
                            <small class="text-muted">No notifications.</small>
                        <?php else: ?>
                            <form action="/notifications/clear" method="post" class="">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-sm btn-danger">
                                    Clear <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="jumbotron mb-0">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Let us know if your city is not listed!</h5>
                    <p class="lead">If your city  or route is not listed, we would like to get your  feedback so that we can create it too.</p>
                    <a href="#">Learn More</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>