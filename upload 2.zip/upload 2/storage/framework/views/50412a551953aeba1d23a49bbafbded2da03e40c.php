<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <h1 class="display-3"><?php echo e($trip->name); ?></h1>
            <p class="lead"><?php echo e($trip->description); ?></p>
            <a href="/post/<?php echo e($trip->post_id); ?>">Back to original post.</a>
        </div>
    </div>
    <div class="container section">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success" role="alert">
                <strong>Success!</strong> <?php echo e(Session::get('success')); ?></a>.
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        Trip Info <span class="tag tag-default"><?php echo e($trip->status()); ?></span>
                    </div>
                    <div class="card-block">
                        <div class="media">
                            <a class="media-left" href="/user/<?php echo e($trip->host->id); ?>">
                                <img class="media-object rounded-circle" src="<?php echo e($trip->host->avatarUrl(45)); ?>" width="45">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading" style="font-size: 14px">Hosted By</h4>
                                <?php echo e($trip->host->fullName()); ?>

                            </div>
                        </div>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <ul class="pl-1">
                                <li>Departure: <?php echo e($trip->departure_datetime); ?></li>
                                <li>Departure Address: <?php echo e($trip->departure_pcode); ?></li>
                                <li>Arrival: <?php echo e(($trip->arrival_datetime)? $trip->arrival_datetime : ''); ?></li>
                                <li>Arrival Address: <?php echo e($trip->arrival_pcode); ?> </li>
                                <li>Cost: <?php echo e($trip->cost()); ?></li>
                            </ul>
                        </li>
                        <li class="list-group-item">
                            <h6 class="font-weight-normal mb-1">Riders:</h6>
                            <?php $__currentLoopData = $trip->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div <?php if(! $loop->last && count($trip->users) > 1): ?> style="margin-bottom: 5px;" <?php endif; ?>>
                                    <div class="media">
                                        <a class="media-left" href="#">
                                            <img class="img-fluid rounded-circle mr-1" src="<?php echo e($user->avatarUrl(45)); ?>" width="45" alt="">
                                        </a>
                                        <div class="media-body">
                                            <div><?php echo e($user->fullName()); ?></div>
                                            <?php if($user->pivot->rating != null): ?>
                                                <div class="ratings">
                                                    <?php for($i = 0; $i < $user->pivot->rating; $i++): ?>
                                                        <i class="fa fa-star"></i>
                                                    <?php endfor; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </li>
                        <?php if(Auth::user()->id != $trip->host->id && $trip->isRider(Auth::user()) != null): ?>
                            <li class="list-group-item">
                                <?php if($trip->isRider(Auth::user())->pivot->rating == null): ?>
                                        <form action="/trip/<?php echo e($trip->id); ?>/rate" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <h5 class="font-weight-normal mb-1">Rate your trip!</h5>
                                            <div class="form-group">
                                                <select name="rating">
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10">10</option>
                                                </select>
                                                <?php if($errors->has('rating')): ?>
                                                    <div class="form-control-feedback">
                                                        <?php echo e($error->first('rating')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <button class="btn btn-outline-info btn-block">
                                                Submit!
                                            </button>
                                        </form>
                                        <script>
                                            $(function(){
                                                $('select[name="rating"]').barrating({
                                                    theme: 'fontawesome-stars'
                                                });
                                            });
                                        </script>
                                <?php else: ?>
                                    <div class="text-xs-center">
                                        <h5 class="font-weight-normal" style="margin-bottom: 5px">Thanks for rating!</h5>
                                    </div>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>

                        <?php if((Auth::user()->id == $trip->host->id  || Auth::user()->hasRole('admin')) && empty($trip->arrival_datetime)): ?>
                            <li class="list-group-item">
                                <form action="/trip/<?php echo e($trip->id); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('patch')); ?>

                                    <button class="card-link btn btn-outline-warning btn-block">
                                        Complete Trip
                                    </button>
                                </form>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        Message Board
                    </div>
                    <div class="card-block">
                        <?php if(count($trip->messages) > 0): ?>
                            <?php $__currentLoopData = $trip->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="media" <?php if(! $loop->last && count($trip->messages) > 1): ?> style="margin-bottom: 10px;" <?php endif; ?>>
                                    <a class="media-left" href="/user/<?php echo e($message->sender->id); ?>">
                                        <img class="media-object rounded-circle" src="<?php echo e($message->sender->avatarUrl(45)); ?>" width="45">
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading" style="font-size: 14px"><?php echo e($message->sender->fullName()); ?> <small class="text-muted"><?php echo e($message->created_at->diffForHumans()); ?></small></h4>
                                        <?php echo e($message->body); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php else: ?>
                            <div class="section text-xs-center">
                                <h4>No group messages? <i class="fa fa-frown-o"></i></h4>
                                <p class="lead mb-0">Get to know each other because it's going to be a ride!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <form action="/trip/<?php echo e($trip->id); ?>/message" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <textarea name="body" rows="3" class="form-control" placeholder="Drop a message..." minlength="1"></textarea>
                                <span class="input-group-btn">
                                    <button class="btn btn-primary h-100">Send!</button>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>