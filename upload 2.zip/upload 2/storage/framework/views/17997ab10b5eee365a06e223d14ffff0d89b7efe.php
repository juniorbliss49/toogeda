<?php $__env->startSection('content'); ?>
    <div class="container section text-xs-center">
        <div class="row flex-items-xs-center">
            <div class="col-xs-8">
                <img src="/images/404.gif" alt="" class="img-fluid" width="340">
                <div style="font-size: 86px">404</div>
                <h1 style="font-weight: 300;">OOOPPS.! THE PAGE YOU WERE LOOKING FOR, COULDN'T BE FOUND.</h1>
                <a href="/">Return back home</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>